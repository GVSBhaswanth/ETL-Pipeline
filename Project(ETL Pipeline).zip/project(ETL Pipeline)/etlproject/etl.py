import pandas as pd
from pymongo import MongoClient

# Extracting the data 
df = pd.read_csv(r"E:\project(ETL Pipeline)\etlproject\2019-Oct.csv")

# Tranforming (or cleaning by dropping null columns)
df.dropna(subset=['event_time', 'event_type', 'product_id'], inplace=True)
# Converts the event_time column from string to datetime format.
df['event_time'] = pd.to_datetime(df['event_time'], errors='coerce')
# Removes any rows where event_time to keep only rows with valid timestamps.
df.dropna(subset=['event_time'], inplace=True)

# Connecting to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client['ecommerce_db']
collection = db['events']

# Loading the  Data
data = df.to_dict(orient='records')
collection.insert_many(data)

print(" Data Ingestion Successful")
print("\n Sample Query Results:")

# Total number of events
total_events = collection.count_documents({})
print(f"Total Events: {total_events}")

# Top 5 most viewed products
pipeline = [
    {"$match": {"event_type": "view"}},
    {"$group": {"_id": "$product_id", "view_count": {"$sum": 1}}},
    {"$sort": {"view_count": -1}},
    {"$limit": 5}
]
top_viewed = list(collection.aggregate(pipeline))
print("\nTop 5 Most Viewed Products:")
for item in top_viewed:
    print(f"Product ID: {item['_id']}, Views: {item['view_count']}")

# Count of each event type
event_counts = collection.aggregate([
    {"$group": {"_id": "$event_type", "count": {"$sum": 1}}}
])
print("\nEvent Type Counts:")
for event in event_counts:
    print(f"{event['_id'].capitalize()}: {event['count']}")
